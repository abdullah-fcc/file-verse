// gateway.js - WebSocket Gateway for OFS Server
const WebSocket = require('ws');
const net = require('net');
const http = require('http');
const fs = require('fs');
const path = require('path');

// Configuration
const WS_PORT = 8080;           // WebSocket port for browser
const HTTP_PORT = 3000;         // HTTP server for static files
const TCP_HOST = 'localhost';   // Your C++ server host
const TCP_PORT = 9000;          // Your C++ server port (change if needed)

// MIME types for static files
const MIME_TYPES = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
};

// ============================================================================
// HTTP SERVER FOR STATIC FILES
// ============================================================================
const httpServer = http.createServer((req, res) => {
    let filePath = '.' + req.url;
    if (filePath === './') {
        filePath = './index.html';
    }

    const extname = String(path.extname(filePath)).toLowerCase();
    const contentType = MIME_TYPES[extname] || 'application/octet-stream';

    fs.readFile(filePath, (error, content) => {
        if (error) {
            if (error.code === 'ENOENT') {
                res.writeHead(404, { 'Content-Type': 'text/html' });
                res.end('<h1>404 - File Not Found</h1>', 'utf-8');
            } else {
                res.writeHead(500);
                res.end('Server Error: ' + error.code, 'utf-8');
            }
        } else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content, 'utf-8');
        }
    });
});

httpServer.listen(HTTP_PORT, () => {
    console.log(`📁 HTTP Server running on http://localhost:${HTTP_PORT}`);
});

// ============================================================================
// WEBSOCKET SERVER
// ============================================================================
const wss = new WebSocket.Server({ port: WS_PORT });

console.log('\n========================================');
console.log('  OFS WebSocket Gateway Started');
console.log('========================================');
console.log(`🌐 WebSocket Server: ws://localhost:${WS_PORT}`);
console.log(`📡 TCP Backend: ${TCP_HOST}:${TCP_PORT}`);
console.log(`🌍 Web Interface: http://localhost:${HTTP_PORT}`);
console.log('========================================\n');

let connectionCount = 0;

wss.on('connection', (ws) => {
    connectionCount++;
    const clientId = connectionCount;
    console.log(`[CLIENT ${clientId}] ✅ WebSocket connected`);

    // Create TCP connection to C++ server
    const tcpClient = new net.Socket();
    let isConnected = false;
    let reconnectAttempts = 0;
    const MAX_RECONNECT = 3;
    let reconnectTimer = null;

    // Connect to C++ server
    const connectToBackend = () => {
        console.log(`[CLIENT ${clientId}] 🔌 Connecting to C++ server...`);
        
        tcpClient.connect(TCP_PORT, TCP_HOST, () => {
            console.log(`[CLIENT ${clientId}] ✅ Connected to C++ server`);
            isConnected = true;
            reconnectAttempts = 0;
        });
    };

    connectToBackend();

    // Handle messages from browser (WebSocket -> TCP)
    ws.on('message', (message) => {
        try {
            const data = message.toString();
            const jsonData = JSON.parse(data);
            console.log(`[CLIENT ${clientId}] 📤 WS->TCP: ${jsonData.operation} (req: ${jsonData.request_id})`);

            if (!isConnected) {
                const errorResp = {
                    status: 'error',
                    operation: jsonData.operation || 'unknown',
                    request_id: jsonData.request_id || 'unknown',
                    error_code: 503,
                    error_message: 'Backend server not connected. Please wait...'
                };
                ws.send(JSON.stringify(errorResp));
                return;
            }

            // Forward to C++ server with newline delimiter
            tcpClient.write(data + '\n');
        } catch (error) {
            console.error(`[CLIENT ${clientId}] ❌ Error processing WS message:`, error.message);
            ws.send(JSON.stringify({
                status: 'error',
                error_code: 500,
                error_message: 'Gateway error: ' + error.message
            }));
        }
    });

    // Handle messages from C++ server (TCP -> WebSocket)
    let tcpBuffer = '';
    tcpClient.on('data', (data) => {
        try {
            tcpBuffer += data.toString();
            
            // Process complete JSON messages (split by newline)
            const messages = tcpBuffer.split('\n');
            tcpBuffer = messages.pop() || ''; // Keep incomplete message in buffer

            messages.forEach(msg => {
                if (msg.trim()) {
                    try {
                        const jsonData = JSON.parse(msg);
                        console.log(`[CLIENT ${clientId}] 📥 TCP->WS: ${jsonData.operation} (status: ${jsonData.status})`);
                        
                        if (ws.readyState === WebSocket.OPEN) {
                            ws.send(msg);
                        }
                    } catch (e) {
                        console.error(`[CLIENT ${clientId}] ⚠️  Invalid JSON from backend:`, msg.substring(0, 100));
                    }
                }
            });
        } catch (error) {
            console.error(`[CLIENT ${clientId}] ❌ Error processing TCP data:`, error.message);
        }
    });

    // Handle TCP connection errors
    tcpClient.on('error', (error) => {
        console.error(`[CLIENT ${clientId}] ❌ TCP error:`, error.message);
        isConnected = false;

        // Send error to browser
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({
                status: 'error',
                error_code: 503,
                error_message: 'Backend connection failed. Retrying...'
            }));
        }

        // Attempt reconnection
        if (reconnectAttempts < MAX_RECONNECT && !reconnectTimer) {
            reconnectAttempts++;
            console.log(`[CLIENT ${clientId}] 🔄 Reconnect attempt ${reconnectAttempts}/${MAX_RECONNECT}...`);
            reconnectTimer = setTimeout(() => {
                reconnectTimer = null;
                connectToBackend();
            }, 2000);
        }
    });

    // Handle TCP connection close
    tcpClient.on('close', () => {
        console.log(`[CLIENT ${clientId}] 🔌 TCP connection closed`);
        isConnected = false;
        
        if (ws.readyState === WebSocket.OPEN) {
            ws.close(1011, 'Backend disconnected');
        }
    });

    // Handle WebSocket close
    ws.on('close', () => {
        console.log(`[CLIENT ${clientId}] 👋 WebSocket disconnected`);
        if (reconnectTimer) {
            clearTimeout(reconnectTimer);
        }
        if (isConnected || tcpClient.connecting) {
            tcpClient.destroy();
        }
    });

    // Handle WebSocket errors
    ws.on('error', (error) => {
        console.error(`[CLIENT ${clientId}] ❌ WebSocket error:`, error.message);
        if (reconnectTimer) {
            clearTimeout(reconnectTimer);
        }
        if (isConnected || tcpClient.connecting) {
            tcpClient.destroy();
        }
    });
});

// Handle WebSocket server errors
wss.on('error', (error) => {
    console.error('❌ [GATEWAY] WebSocket server error:', error);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n[GATEWAY] 🛑 Shutting down...');
    
    httpServer.close(() => {
        console.log('[GATEWAY] ✅ HTTP server closed');
    });
    
    wss.close(() => {
        console.log('[GATEWAY] ✅ WebSocket server closed');
        process.exit(0);
    });
});

console.log('✅ Gateway ready! Waiting for connections...\n');
console.log('📌 Open your browser and go to: http://localhost:3000\n');